from nltk import agreement
from nltk.metrics.distance import masi_distance
from nltk.metrics.distance import jaccard_distance

import pandas as pd

annotfile = "E:/python/consistency/test-iaa.xlsx"

df = pd.read_excel(annotfile).iloc[47500:50000]

annots = []


def create_annot(an):
    """
    Create frozensets with the unique label
    or with both labels splitting on pipe.
    Unique label has to go in a list so that
    frozenset does not split it into characters.
    """
    if "," in str(an):
        an = frozenset(an.split(","))
    else:
        # single label has to go in a list
        # need to cast or not depends on your data
        # an = frozenset([str(int(an))])
        an = frozenset([str(an)])
    return an


for idx, row in df.iterrows():
    # print(row)
    annot_id = row.annotItem + str.zfill(str(idx), 3)
    annot_coder1 = ['coder1', annot_id, create_annot(row.coder1)]
    annot_coder2 = ['coder2', annot_id, create_annot(row.coder2)]
    # annot_coder3 = ['coder3', annot_id, create_annot(row.coder3)]
    annots.append(annot_coder1)
    annots.append(annot_coder2)
    # annots.append(annot_coder2)

# based on https://stackoverflow.com/questions/45741934/
jaccard_task = agreement.AnnotationTask(distance=jaccard_distance)
masi_task = agreement.AnnotationTask(distance=masi_distance)
tasks = [jaccard_task, masi_task]
for task in tasks:
    task.load_array(annots)
    print("Statistics for dataset using {}".format(task.distance))
    print("C: {}\nI: {}\nK: {}".format(task.C, task.I, task.K))
    # print("Pi: {}".format(task.pi()))
    # print("Kappa: {}".format(task.kappa()))
    # print("Multi-Kappa: {}".format(task.multi_kappa()))
    # print("Alpha: {}".format(task.alpha()))
    print("{}".format(task.pi()))
    print("{}".format(task.kappa()))
    print("{}".format(task.multi_kappa()))
    print("{}".format(task.alpha()))