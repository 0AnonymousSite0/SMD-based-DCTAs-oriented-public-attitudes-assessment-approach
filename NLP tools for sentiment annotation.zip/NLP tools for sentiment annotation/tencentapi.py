import json
import pandas as pd
import csv
import time
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.nlp.v20190408 import nlp_client, models

def get_sentiment(text):
    try:
        # 实例化一个认证对象，入参需要传入腾讯云账户secretId，secretKey,此处还需注意密钥对的保密
        # 密钥可前往https://console.cloud.tencent.com/cam/capi网站进行获取
        cred = credential.Credential("", "")
        # 实例化一个http选项，可选的，没有特殊需求可以跳过
        httpProfile = HttpProfile()
        httpProfile.endpoint = "nlp.tencentcloudapi.com"

        # 实例化一个client选项，可选的，没有特殊需求可以跳过
        clientProfile = ClientProfile()
        clientProfile.httpProfile = httpProfile
        # 实例化要请求产品的client对象,clientProfile是可选的
        client = nlp_client.NlpClient(cred, "ap-guangzhou", clientProfile)

        # 实例化一个请求对象,每个接口都会对应一个request对象
        req = models.SentimentAnalysisRequest()
        params = {
            "Text": text,
            "Mode": "3class"
        }
        req.from_json_string(json.dumps(params))

        # 返回的resp是一个SentimentAnalysisResponse的实例，与请求对象对应
        resp = client.SentimentAnalysis(req)
        # 输出json格式的字符串回包
        j = json.loads(resp.to_json_string())
        return [j['Positive'],j['Neutral'],j['Negative'],j['Sentiment']]

    except TencentCloudSDKException as err:
        print(err)

f = open(r'tx.csv', mode="w", newline="")
csvwriter = csv.writer(f)
data = pd.read_csv(r'sentiment label.csv', encoding='UTF-8')
text_list = data["text"]
positive_prob_list = []
neutral_prob_list = []
negative_prob_list = []
sentiment_list = []
sum = 0
for text in text_list:
    sum += 1
    print(sum)
    time.sleep(0.5)
    items = get_sentiment(text)
    positive_prob_list.append(items[0])
    neutral_prob_list.append(items[1])
    negative_prob_list.append(items[2])
    sentiment_list.append(items[3])
    row = [items[0], items[1], items[2], items[3]]
    csvwriter.writerow(row)

data['positive_prob'] = positive_prob_list
data['neutral_prob'] = neutral_prob_list
data['negative_prob'] = negative_prob_list
data['sentiment'] = sentiment_list

data.to_csv(r'sentiment label.csv', index=False)
f.close()