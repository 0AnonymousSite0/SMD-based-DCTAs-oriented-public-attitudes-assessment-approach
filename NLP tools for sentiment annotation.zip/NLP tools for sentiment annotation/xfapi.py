#!/usr/bin/python
# -*- coding: UTF-8 -*-
import time
import urllib.request
import urllib.parse
import json
import hashlib
import base64
import pandas as pd
import csv
#接口地址
url =""
#开放平台应用ID
x_appid = ""
#开放平台应用接口秘钥
api_key = ""

def get_sentiment(text):
    body = urllib.parse.urlencode({'text': text}).encode('utf-8')
    param = {"type": "dependent"}
    x_param = base64.b64encode(json.dumps(param).replace(' ', '').encode('utf-8'))
    x_time = str(int(time.time()))
    x_checksum = hashlib.md5(api_key.encode('utf-8') + str(x_time).encode('utf-8') + x_param).hexdigest()
    x_header = {'X-Appid': x_appid,
                'X-CurTime': x_time,
                'X-Param': x_param,
                'X-CheckSum': x_checksum}
    req = urllib.request.Request(url, body, x_header)
    result = urllib.request.urlopen(req)
    result = result.read()
    result.decode('utf-8')
    result = json.loads(result)
    return result

f = open(r'xf.csv', mode="w", newline="")
csvwriter = csv.writer(f)
data = pd.read_csv(r'sentiment label.csv', encoding='UTF-8')
text_list = data["text"]
sentiment_list = []
# text = '各位.打开天府健康通，点击健康码下的“社区报备”，按实际情况填写提交；（我填的是从华西医院出发，到家自己家，风险类型选的疑似和确诊有轨迹重合那个）2.接听社区工作人员的电话访问；3.应急黄码人员需要居家隔离三天，期间乘私家车去黄码定点医院做三天三检的核酸，每两次间隔24小时；4.等待恢复绿码………社区工作人员半夜还在打电话，辛苦了…'
# print(len(text))
# text = text.encode("utf-8")
# print(len(text))
# items = get_sentiment(text)
# print(items)
sum = 0
for text in text_list:
    time.sleep(0.5)
    sum += 1
    print(sum)
    text = text.encode("utf-8")
    if len(text) < 501:
        items = get_sentiment(text)
        print(items)
        try:
            sentiment_list.append(items["data"]["sentiment"])
            row = [items["data"]["sentiment"]]
            csvwriter.writerow(row)
        except:
            sentiment_list.append(items["data"]["sa"][0]["sentiment"])
            row = [items["data"]["sa"][0]["sentiment"]]
            csvwriter.writerow(row)
    else:
        sentiment_list.append('3')
        row = ['3']
        csvwriter.writerow(row)

data['sentiment'] = sentiment_list

data.to_csv(r'sentiment label.csv', index=False)
f.close()
