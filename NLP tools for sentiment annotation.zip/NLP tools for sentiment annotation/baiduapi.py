import aip
import pandas as pd
import csv
import time

client_appid = ''
client_ak = ''
client_sk = ''
my_nlp = aip.nlp.AipNlp(client_appid, client_ak, client_sk)

f = open(r'bd.csv', mode="w", newline="")
csvwriter = csv.writer(f)
data = pd.read_csv(r'sentiment label.csv', encoding='UTF-8')
text_list = data["text"]
confidence_list = []
negative_prob_list = []
positive_prob_list = []
sentiment_list = []
sum = 0

for text in text_list:
    sum += 1
    print(sum)
    time.sleep(0.5)
    try:
        items = my_nlp.sentimentClassify(text)['items'][0]
        confidence_list.append(items['confidence'])
        negative_prob_list.append(items['negative_prob'])
        positive_prob_list.append(items['positive_prob'])
        sentiment_list.append(items['sentiment'])
        row = [items['negative_prob'], items['positive_prob'], items['sentiment'], items['confidence']]
    except:
        confidence_list.append('')
        negative_prob_list.append('')
        positive_prob_list.append('')
        sentiment_list.append('')
        row = ['', '', '', '']
    csvwriter.writerow(row)


data['negative_prob'] = negative_prob_list
data['positive_prob'] = positive_prob_list
data['sentiment'] = sentiment_list
data['confidence'] = confidence_list

data.to_csv(r'sentiment label.csv', index=False)
f.close()