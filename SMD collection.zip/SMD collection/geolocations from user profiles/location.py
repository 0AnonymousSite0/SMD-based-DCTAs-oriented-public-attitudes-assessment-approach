import random
import requests
import csv
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor
import pandas as pd
import time

data = pd.read_csv(r'user_id.csv', encoding='gb18030') #csv重新保存cp936
user_id_list = data["user_id"]
# user_location_list = []
f = open('cs.csv', mode='w', newline='')
csvwriter = csv.writer(f)
num = 0

def download_one_location(k):
    url = "https://weibo.cn/" + k
    time.sleep(0.2)
    headers = { 'accept':
               }
    proxie_ips = ["117.92.124.151:13167", "182.34.103.161:16520", "113.76.195.166:14120", "117.69.33.6:15424"]
    proxie_ip = random.choice(proxie_ips)
    # print(proxie_ip)
    proxies = {
        "https": proxie_ip
              }
    resp = requests.get(url, headers=headers, proxies=proxies)
    global num
    num += 1
    print(num)
    if num % 100 == 0:
        time.sleep(120)
    # resp = requests.get(url, headers=headers)
    html = BeautifulSoup(resp.content, 'html.parser')
    try:
        user_info = html.find('span', class_="ctt").text.replace(' ','').replace('\n','').split(' ')[-2]
    except:
        user_info = '其他'
    if "/" in user_info:
        user_location = user_info.split('/')[-1]
    else:
        user_location = user_info
    user_location_list.append(user_location)
    print(user_location)
    row = [k, user_location]
    csvwriter.writerow(row)
    resp.close()

if __name__ == "__main__":

    with ThreadPoolExecutor(10) as t:
        for i in user_id_list:
            t.submit(download_one_location, str(i))
    print(len(user_location_list))

    # for i in user_id_list:
    #     download_one_location(str(i))

    # download_one_location("1560642940")



