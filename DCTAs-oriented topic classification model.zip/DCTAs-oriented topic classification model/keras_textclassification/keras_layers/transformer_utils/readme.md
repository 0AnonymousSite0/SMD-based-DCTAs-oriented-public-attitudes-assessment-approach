reference:
    1.code from github:
        author:CyberZHG;
        url: https://github.com/CyberZHG/keras-transformer.
    2.change:
        some code of function and so on.

