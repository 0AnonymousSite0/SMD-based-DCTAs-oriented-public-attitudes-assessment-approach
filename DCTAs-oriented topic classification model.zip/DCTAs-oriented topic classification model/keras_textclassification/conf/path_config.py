# -*- coding: UTF-8 -*-

import os

# 项目的根目录
path_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
path_root = path_root.replace('\\', '/')

# path of embedding
path_embedding_random_char = path_root + '/data/embeddings/term_char.txt'
path_embedding_random_word = path_root + '/data/embeddings/term_word.txt'
path_embedding_bert = path_root + '/data/embeddings/chinese_L-12_H-768_A-12/'
path_embedding_xlnet = path_root + '/data/embeddings/chinese_xlnet_base_L-12_H-768_A-12/'
path_embedding_albert = path_root + '/data/embeddings/albert_base_zh'
path_embedding_vector_word2vec_char = path_root + '/data/embeddings/w2v_model_wiki_char.vec'
path_embedding_vector_word2vec_word = path_root + '/data/embeddings/w2v_model_merge_short.vec'

# classify data of c
path_c_train = path_root + '/data/multi_category/train.csv'
path_c_valid = path_root + '/data/multi_category/valid.csv'
path_c_test = path_root + '/data/multi_category/test.csv'

# classify data of l
path_l_train = path_root + '/data/multi_label/train.csv'
path_l_valid = path_root + '/data/multi_label/valid.csv'
path_l_label = path_root + '/data/multi_label/labels.csv'

# fast_text config
# 模型目录
path_model_dir =  path_root + "/data/model/fast_text/"
# 语料地址
path_model = path_root + '/data/model/fast_text/model_fast_text.h5'
# 超参数保存地址
path_hyper_parameters =  path_root + '/data/model/fast_text/hyper_parameters.json'
# embedding微调保存地址
path_fineture = path_root + "/data/model/fast_text/embedding_trainable.h5"
